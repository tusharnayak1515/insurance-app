package com.insurance.policyapp.dto;

public class RegisterRequest {
	private String username;
	private String email;
	private String mobile;
	private String password;
	
	public RegisterRequest() {
		
	}

	public RegisterRequest(String username, String email, String mobile, String address, String password) {
		super();
		this.username = username;
		this.email = email;
		this.mobile = mobile;
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "RegisterRequest [username=" + username + ", email=" + email + ", mobile=" + mobile + ", password=" + password + "]";
	}
	
}
