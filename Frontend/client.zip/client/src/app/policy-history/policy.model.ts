export interface Policy {
    series: string;
    policyName: string;
    date: string;
    status: string;
  }
  