export interface Policy {
    serialNo: number;
    policyName: string;
    category: string;
    sumAssurance: number;
    premium: number;
    tenure: number;
    creationDate: string;
  }
  