class Policycategory {
    constructor(
      public categoryId: number | null,
      public name: string,
    ) {}
  }
  
  export default Policycategory;