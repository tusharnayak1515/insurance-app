class RegisterUser {
    constructor(
      public username: string,
      public email: string,
      public mobile: string,
      public password:string
    ) {}
  }
  
  export default RegisterUser;
  